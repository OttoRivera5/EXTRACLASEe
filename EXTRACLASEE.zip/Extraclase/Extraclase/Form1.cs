﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Windows.Forms.DataVisualization.Charting;

namespace Extraclase
{
    public partial class Form1 : Form
    {
        public Form1()
        {

            {
                InitializeComponent();

                // Crear una instancia del gráfico
                Chart chart = chart1;

                // Agregar los datos de la tabla de gastos trimestrales
                int[,] gastosTrimestrales = {
        { 120, 85, 180 },
        { 420, 105, 225 },
        { 360, 90, 160 }
    };

                // Limpiar el gráfico (por si ya tiene datos)
                chart.Series.Clear();

                // Configurar el estilo del gráfico
                chart.ChartAreas[0].AxisX.MajorGrid.Enabled = false;
                chart.ChartAreas[0].AxisY.MajorGrid.Enabled = false;
                chart.ChartAreas[0].AxisX.Title = "Trimestre";
                chart.ChartAreas[0].AxisY.Title = "Gasto";

                string[] categorias = { "Agua", "Luz", "Gas" };

                // Crear una serie para cada fila de la tabla
                for (int i = 0; i < gastosTrimestrales.GetLength(0); i++)
                {
                    Series series = new Series();
                    series.ChartType = SeriesChartType.Bar;
                    series.Name = categorias[i];

                    // Agregar los datos de cada trimestre a la serie
                    for (int j = 0; j < gastosTrimestrales.GetLength(1); j++)
                    {
                        series.Points.AddXY("T" + (j + 1), gastosTrimestrales[i, j]);
                    }

                    // Agregar la serie al gráfico
                    chart.Series.Add(series);





                    // Crear la tabla de datos
                    DataTable table = new DataTable();

                    // Agregar las columnas a la tabla
                    table.Columns.Add("Trimestre", typeof(string));
                    table.Columns.Add("Agua", typeof(int));
                    table.Columns.Add("Luz", typeof(int));
                    table.Columns.Add("Gas", typeof(int));

                    // Agregar las filas a la tabla con los datos de gastos trimestrales
                    table.Rows.Add("T1", 120, 85, 180);
                    table.Rows.Add("T2", 420, 105, 225);
                    table.Rows.Add("T3", 360, 90, 160);

                    // Crear el control DataGridView
                    DataGridView dataGridView = new DataGridView();
                    dataGridView.Dock = DockStyle.Fill;
                    dataGridView.AutoGenerateColumns = true;
                    dataGridView.DataSource = table;

                    // Agregar el control DataGridView al formulario
                    Controls.Add(dataGridView);
                }
            }
        }
    }
}

        
    

    

